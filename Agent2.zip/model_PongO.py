import torch

l1 = 6 #A
l2 = 220
l4 = 2


MAX_EPISODES = 5000



model = torch.nn.Sequential(
    torch.nn.Linear(l1, l2),
    torch.nn.LeakyReLU(),
    torch.nn.Linear(l2,l4),
    torch.nn.Softmax(dim=0) #C
)
