from PongO_Final import Pong
import time
import numpy as np
import torch
from model_PongO import *
from statistik_PongO import Statistik_PongO


print("Testen")
MAX_DUR = 50000
model.load_state_dict(torch.load("model_state_PongO.dat"))
model.eval()

env = Pong(show=False)
games = 100
state1,done = env.reset()
done = False
stats = Statistik_PongO(msg='PongO_220HiddenNeuronen_5000_epoch_training')

for i in range(games):
    t=0
    while not done:
        pred = model(torch.from_numpy(state1).float())
        action = np.random.choice(np.array([0,1]), p=pred.data.numpy())
        state2, _,done = env.step(action)
        state1 = state2
        t += 1
        if t > MAX_DUR:
            break
        # time.sleep(0.03)
    stats.add(env.score)
    print("Lost",i+1,"von",games)
    print('Score: ', env.score)
    print('Treffer: ', env.env_treffer)
    state1, done = env.reset()
    done = False

del(env)
stats.end_writing()
