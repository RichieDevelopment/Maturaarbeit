from PongO_Final import Pong
import numpy as np
import torch
from model_PongO import *
from statistik_PongO import Statistik_PongO



MAX_DUR = 50000
gamma = 0.95
score = []
expectation = 0.0
learning_rate = 0.0001
env = Pong(show=False)

def discount_rewards(rewards, gamma):
    lenr = len(rewards)
    disc_return = torch.pow(gamma,torch.arange(lenr).float()) * rewards
    disc_return /= disc_return.max()
    return disc_return


def loss_fn(preds, r):
    return -1 * torch.sum(r * torch.log(preds))



print("Trainieren")
print()

stats = Statistik_PongO(model=model,lr=learning_rate,gamma=gamma,msg='PongO_220HiddenNeuronen_5000_epoch_training')

optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
# optimizer = torch.optim.Adam()
# scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, factor=0.8, patience=2, verbose=True)

max = 0
for episode in range(MAX_EPISODES):
    print("Episode",episode+1,"von",MAX_EPISODES)
    if env.score >= stats.score_schwellwert:
        break
    curr_state, done = env.reset()
    done = False
    transitions = []


    for t in range(MAX_DUR):
        act_prob = model(torch.from_numpy(curr_state).float())
        action = np.random.choice(np.array([0,1]), p=act_prob.data.numpy())
        prev_state = curr_state
        curr_state,_,done = env.step(action)
        transitions.append((prev_state, action, t+1))
        if done:
            print('Score: ', env.score)
            print('Treffer: ', env.env_treffer)
            break
    treffer = env.score
    if treffer > max:
        max = treffer
    ep_len = len(transitions)
    score.append(ep_len)
    reward_batch = torch.Tensor([r for (s,a,r) in transitions]).flip(dims=(0,))
    disc_returns = discount_rewards(reward_batch,gamma)
    state_batch = torch.Tensor([s for (s,a,r) in transitions])
    action_batch = torch.Tensor([a for (s,a,r) in transitions])
    pred_batch = model(state_batch)
    prob_batch = pred_batch.gather(dim=1,index=action_batch.long().view(-1,1)).squeeze()
    loss = loss_fn(prob_batch, disc_returns)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    # scheduler.step(loss)

    stats.add(env.score)

del(env)


print('Maximal Score: ', max)
torch.save(model.state_dict(), "model_state_PongO.dat")
print("model_state_raumschiff.dat","geschrieben")
stats.end_writing()
stats.end_model(max,episode)