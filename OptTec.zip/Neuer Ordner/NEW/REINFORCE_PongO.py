from PongO_Final import Pong
import numpy as np
import torch
from datetime import datetime as datetime
from collections import deque
import os
import random
from statistik_PongO import Statistik_PongO
import optuna








print("Trainieren")
print()









# optimizer = torch.optim.Adam()
# scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, factor=0.90, patience=1, verbose=True)



class Reinforce():
    def __init__(self,trial, gamma=0.99,learning_rate=0.003,mem_size=4000,batch_size=32,hidden_n=200):
        self.MAX_DUR = 50000
        self.gamma = trial.suggest_categorical('gamma', [0.9,0.95,0.99])
        self.score = []
        self.expectation = 0.0
        self.learning_rate = trial.suggest_categorical('learning_rate', [0.1,0.01,0.001,0.0001,0.00001])

        self.list_stat = []
        self.list_stat_counter = 1
        self.list_last_state = ''
        self.Namensgebung = True
        self.same_size = True

        self.env = Pong(border=True,show=False)

        self.mem_size = trial.suggest_categorical('mem_size', [1000,2000,3000,4000,5000,6000,7000,8000,9000,10000])
        self.replay = deque(maxlen=self.mem_size)
        self.batch_size = trial.suggest_int('batch_size', 1, 300)

        # model
        input_n = 5
        hidden_n = trial.suggest_int('hidden_n', 80,200)
        output_n = 2

        self.MAX_EPISODES = 1000
        self.activation_func_dict = {
            'LeakyReLU': torch.nn.LeakyReLU,
            'ReLU': torch.nn.ReLU,
            'ReLU6': torch.nn.ReLU6,
            'Sigmoid': torch.nn.Sigmoid,
            'ELU': torch.nn.ELU,
            'SELU': torch.nn.SELU
        }
        self.activation_func = trial.suggest_categorical('activation_func', ['LeakyReLU','ReLU','ReLU6','Sigmoid','ELU','SELU'])

        self.dropout_1 = trial.suggest_float('dropout_1', 0, 0.9, step=0.1)
        self.dropout_2 = trial.suggest_float('dropout_2', 0, 0.9, step=0.1)

        self.model = torch.nn.Sequential(
            torch.nn.Linear(input_n, hidden_n),
            torch.nn.Dropout(self.dropout_1),
            self.activation_func_dict[self.activation_func](),
            torch.nn.Linear(hidden_n, output_n),
            torch.nn.Dropout(self.dropout_2),
            torch.nn.Softmax(dim=0)
        )

        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.learning_rate)
        self.max = 0
        self.total_score = 0
        self.end_episode = 0
        self.total_losses = 0



        self.stats = Statistik_PongO(model=self.model,
                                     lr=self.learning_rate,
                                     gamma=self.gamma,
                                     bs=self.batch_size,
                                     ms=self.mem_size,
                                     msg='Skipping_PongO_2')

    def discount_rewards(self,rewards, gamma):
        lenr = len(rewards)
        disc_return = torch.pow(gamma, torch.arange(lenr).float()) * rewards
        disc_return /= disc_return.max()
        return disc_return

    def loss_fn(self,preds, r):
        return -1 * torch.sum(r * torch.log(preds))

    def train(self):
        for episode in range(self.MAX_EPISODES):
            # print("Episode", episode + 1, "von", self.MAX_EPISODES)
            if self.env.score >= 7:
                break
            curr_state, done = self.env.reset()
            done = False
            transitions = []  # B

            for t in range(self.MAX_DUR):
                act_prob = self.model(torch.from_numpy(curr_state).float())
                try:
                    action = np.random.choice(np.array([0, 1]), p=act_prob.data.numpy())
                except Exception as e:
                    print(e)
                    print('curr_state: ', curr_state)
                    print('done: ', done)
                    print('act_prob: ', act_prob)

                prev_state = curr_state
                for _ in range(600):
                    curr_state, reward, done = self.env.step(action)
                self.replay.append((prev_state, action, reward))
                if done or self.env.env_treffer >= 60:
                    # print('Score: ', self.env.score)
                    self.total_score += self.env.score
                    # print('Treffer: ', self.env.env_treffer)
                    break
            treffer = self.env.score
            if treffer > self.max:
                self.max = treffer

            if len(self.replay) > self.batch_size:
                minibatch = random.sample(self.replay, self.batch_size)

                ep_len = len(transitions)
                self.score.append(ep_len)
                reward_batch = torch.Tensor([r for (s, a, r) in minibatch]).flip(dims=(0,))
                disc_returns = self.discount_rewards(reward_batch, self.gamma)
                state_batch = torch.Tensor([s for (s, a, r) in minibatch])
                action_batch = torch.Tensor([a for (s, a, r) in minibatch])
                pred_batch = self.model(state_batch)
                prob_batch = pred_batch.gather(dim=1, index=action_batch.long().view(-1, 1)).squeeze()
                loss = self.loss_fn(prob_batch, disc_returns)
                self.total_losses += loss
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                # scheduler.step(loss)

            self.stats.add(self.env.score)
            self.end_episode = episode

    def return_advantage(self):
        print('loss: ',self.total_losses)
        print('max: ', self.max)
        print('episodes played: ', self.end_episode)
        return self.max / self.end_episode

    def evaluate(self):
        print('Total Score: ', self.total_score)
        print('Maximal Score: ', max)
        torch.save(model.state_dict(), "model_state_PongO.dat")
        print("model_state_raumschiff.dat", "geschrieben")
        datei = open("statistik_Policy_Gradient.csv", 'w')
        self.stats.end_writing()
        self.stats.end_model(max, self.end_episode)

if __name__ == '__main__':

    def objective(trial):
        ai_total_advantage = 0
        for _ in range(3):
            ai = Reinforce(trial)
            ai.train()
            ai_total_advantage += ai.return_advantage()
        return ai_total_advantage / 3

    study = optuna.create_study(direction='maximize')
    study.optimize(objective, n_trials=20)

    # Best Params
    best_params = study.best_params
    found_gamma = best_params['gamma']
    found_learning_rate = best_params['learning_rate']
    found_mem_size = best_params['mem_size']
    found_batch_size = best_params['batch_size']
    found_hidden_n = best_params['hidden_n']
    found_dropout_1 = best_params['dropout_1']
    found_dropout_2 = best_params['dropout_2']

    # Evaluate
    print(f"""
    Best Params:
        gamma: {found_gamma}
        learning_rate: {found_learning_rate}
        mem_size: {found_mem_size}
        batch_size: {found_batch_size}
        hidden_n: {found_hidden_n}
        dropout_1: {found_dropout_1}
        dropout_2: {found_dropout_2}
    """)
