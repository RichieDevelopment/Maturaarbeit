from PongO_Final import Pong
import numpy as np
import torch
from model_PongO import *
from datetime import datetime as datetime
from collections import deque
import os
import random
from statistik_PongO import Statistik_PongO



MAX_DUR = 50000
gamma = 0.95
score = []
expectation = 0.0
learning_rate = 0.009
list_stat = []
list_stat_counter = 1
list_last_state = ''
Namensgebung = True
same_size = True

env = Pong(show=False, border=True)

def discount_rewards(rewards, gamma=0.99):
    lenr = len(rewards)
    disc_return = torch.pow(gamma,torch.arange(lenr).float()) * rewards
    disc_return /= disc_return.max()
    return disc_return


def loss_fn(preds, r):
    return -1 * torch.sum(r * torch.log(preds))



print("Trainieren")
print()



dateTimeobj = datetime.now()
dateString = str(dateTimeobj.day) + '%' + str(dateTimeobj.month) + '%' + str(dateTimeobj.year) + '&' + str(
    dateTimeobj.hour) + '%' + str(dateTimeobj.minute)
dateString_writing = str(dateTimeobj.day) + '.' + str(dateTimeobj.month) + '.' + str(dateTimeobj.year) + '_' + str(
    dateTimeobj.hour) + ':' + str(dateTimeobj.minute)


new_statistik = True
if os.path.isfile('statistik_Policy_Gradient_Test1.csv'):
    new_statistik = False
    datei = open("statistik_Policy_Gradient_Test1.csv")
    for i in datei:
        list_stat.append(i.rstrip())
    datei.close()
    anzahl_spalten = list_stat[1].count(';')+1



stats = Statistik_PongO(model=model,
                        lr=learning_rate,
                        gamma=gamma,
                        msg='Skipping_PongO_2_NEW')

optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
# optimizer = torch.optim.Adam()
# scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, factor=0.90, patience=1, verbose=True)

max = 0
gesamt_punktestand = 0
done2 = False
for episode in range(MAX_EPISODES):
    print("Episode",episode+1,"von",MAX_EPISODES)
    if env.env_treffer >= 8:
        break
    curr_state, done = env.reset()
    done = False
    transitions = []


    for t in range(MAX_DUR):
        act_prob = model(torch.from_numpy(curr_state).float())
        action = np.random.choice(np.array([0,1]), p=act_prob.data.numpy())
        prev_state = curr_state
        for _ in range(600):
            curr_state,_,done = env.step(action)
        transitions.append((prev_state, action, t+1))
        if done:
            print('Score: ', env.score)
            print('Treffer: ', env.env_treffer)
            break
    treffer = env.score
    if treffer > max:
        max = treffer

    ep_len = len(transitions)
    score.append(ep_len)
    reward_batch = torch.Tensor([r for (s, a, r) in transitions]).flip(dims=(0,))
    disc_returns = discount_rewards(reward_batch,gamma)
    state_batch = torch.Tensor([s for (s, a, r) in transitions])
    action_batch = torch.Tensor([a for (s, a, r) in transitions])
    pred_batch = model(state_batch)
    prob_batch = pred_batch.gather(dim=1, index=action_batch.long().view(-1, 1)).squeeze()  # O
    loss = loss_fn(prob_batch, disc_returns)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    # scheduler.step(loss)

    if new_statistik:
        if Namensgebung:
            dateTimeobj = datetime.now()
            dateString = str(dateTimeobj.day) + '%' + str(dateTimeobj.month) + '%' + str(dateTimeobj.year) + '&' + str(
                dateTimeobj.hour) + '%' + str(dateTimeobj.minute)
            list_stat.append(dateString_writing)
            Namensgebung = False

        list_stat.append(str(env.score))
    else:
        if Namensgebung:
            list_stat[0] = list_stat[0] + ';' + dateString_writing
            Namensgebung = False

        if list_stat_counter <= len(list_stat)-1:
            list_stat[list_stat_counter] += ';' + str(env.score)
        else:
            list_stat.append(' ')
            platzhalter = list_stat[2].count(';')-1
            for _ in range(platzhalter):
                list_stat[list_stat_counter] += '; '
            list_stat[list_stat_counter] += ';' + str(env.score)
    list_stat_counter += 1


del(env)

print('Maximal Score: ', max)
torch.save(model.state_dict(), "model_state_PongO.dat")
print("model_state_raumschiff.dat","geschrieben")
datei = open("statistik_Policy_Gradient.csv", 'w')
for i in list_stat:
    datei.write(i + "\n")
datei.close()