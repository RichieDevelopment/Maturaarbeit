import torch

l1 = 6
l2 = 200
l4 = 2


MAX_EPISODES = 1000



model = torch.nn.Sequential(
    torch.nn.Linear(l1, l2),
    torch.nn.ReLU(),
    torch.nn.Linear(l2,l4),
    torch.nn.Softmax(dim=0)
)
